import {
    useEffect,
    useState
} from "react";


import {
    getNhomToppings,
    type NhomTopping
} from "../services/toppingService";


import {
    getCurrentUser
} from "../services/userService";



// =======================
// TYPE USER
// =======================

interface CurrentUser {

    maTaiKhoan: number;

    email: string;

    role: string;

    nhaHang?: {

        maNhaHang: number;

        tenNhaHang: string;

    };

}




function RestaurantTopping() {


    const [

        nhomToppings,

        setNhomToppings

    ] = useState<NhomTopping[]>([]);




    const [

        loading,

        setLoading

    ] = useState<boolean>(true);




    const [

        error,

        setError

    ] = useState<string>("");





    useEffect(() => {


        let isMounted = true;



        const fetchData = async (): Promise<void> => {


            try {


                setLoading(true);

                setError("");



                const user =
                    await getCurrentUser() as CurrentUser;



                if (

                    !user.nhaHang ||

                    !user.nhaHang.maNhaHang

                ) {

                    throw new Error(
                        "Không tìm thấy nhà hàng của tài khoản"
                    );

                }




                const maNhaHang =
                    user.nhaHang.maNhaHang;




                console.log(

                    "Mã nhà hàng:",

                    maNhaHang

                );




                const data =
                    await getNhomToppings(maNhaHang);





                console.log(

                    "Nhóm topping:",

                    data

                );





                if (isMounted) {


                    setNhomToppings(data);


                }



            }

            catch (err) {


                console.error(

                    "Lỗi tải nhóm topping:",

                    err

                );



                if (isMounted) {


                    setError(

                        "Không thể tải dữ liệu nhóm topping"

                    );


                }


            }

            finally {


                if (isMounted) {


                    setLoading(false);


                }


            }


        };





        fetchData();




        return () => {


            isMounted = false;


        };



    }, []);







    return (

        <div>


            <h1>

                Quản lý topping

            </h1>





            {

                loading && (

                    <p>

                        Đang tải dữ liệu...

                    </p>

                )

            }






            {

                error && (

                    <p>

                        {error}

                    </p>

                )

            }







            {

                !loading &&

                !error &&

                nhomToppings.map(

                    (item) => (


                        <div

                            key={

                                item.maNhomTopping

                            }

                        >


                            <h3>

                                {item.tenNhom}

                            </h3>





                            <p>

                                Bắt buộc chọn:

                                {" "}

                                {

                                    item.batBuocChon

                                        ?

                                        "Có"

                                        :

                                        "Không"

                                }


                            </p>






                            <p>

                                Chọn tối đa:

                                {" "}

                                {

                                    item.chonToiDa

                                }


                            </p>




                        </div>


                    )

                )

            }




        </div>

    );

}



export default RestaurantTopping;